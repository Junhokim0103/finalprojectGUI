#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSvgRenderer>
#include <QPushButton>
#include <QWidget>
#include <QPainter>
#include <QPaintEvent>
#include <QTimer>
#include <QLabel>

#include <QCanBus>
#include <QCanBusDevice>
#include <QCanBusFrame>
#include <QDebug>
#include <QProgressBar>
//QT_BEGIN_NAMESPACE
//namespace Ui { class MainWindow; }
//QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *);
    QRectF calculateAspectRatioFit(QSizeF srcSize, QRectF dstRect);
    QPointF transpointCal(void);
    void Rpm(int value,QPainter &painter);
    void CarSpeed(int value,QPainter &painter);
    //int openCanSocket(const char* ifname);
    void openCanSocket(void);
    void warningDraw(QPainter &painter);
    void StartStopDraw(QPainter &painter);
    void AutowayDraw(QPainter &painter);
    void SpeedDraw(QPainter &painter);
private slots:
    //void onMyButtonClicked();
    //void onMyButtonClicked2();
    void onCanFrameReceived();

private:
    //Ui::MainWindow *ui;
    int value = 0;
    uint8_t btnmsg = 0;
    QSvgRenderer* svgRenderer;
    QSvgRenderer* NeedlesvgRenderer;
    int rpmValue = 0;
    int carSpeed = 0;
    QCanBusDevice *device;
    uint8_t Autoway = 0;
    uint8_t startStop = 0;
    uint8_t warning = 1;
    uint8_t SpeedRestrict = 0;
    uint8_t AdasState = 0;
//    QImage AutowayQpix;
//    QImage startQpix;
//    QImage StopQpix;
//    QImage warningQpix;
//    QImage SpeedRestrictQpix;
    QProgressBar *progressBar;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    //QPushButton *myButton;
};
#endif // MAINWINDOW_H
