#include "mainwindow.h"
#include "ui_mainwindow.h"

//#include <QSvgRenderer>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    //, ui(new Ui::MainWindow)
{
    this->setEnabled(true);
    this->resize(480, 272);
    QPalette pal = this->palette();
    pal.setColor(QPalette::Window, Qt::darkGray);  // 또는 QColor("#RRGGBB")
    this->setAutoFillBackground(true);  // 이거 중요!
    this->setPalette(pal);
    //ui->setupUi(this);
   //connect(ui->pushButton, &QPushButton::clicked, this, &MainWindow::onMyButtonClicked);//, &QPushButton::clicked, this, &MainWindow::on_pushButton_clicked);
    //ui->lcdNumber->setBaseSize();
    label_2 = new QLabel(this);
    label_2->setObjectName(QString::fromUtf8("label_2"));
    label_2->setGeometry(QRect(310, 10, 101, 20));
    label = new QLabel(this);
    label->setObjectName(QString::fromUtf8("label"));
    label->setGeometry(QRect(70, 10, 111, 17));
    label_3 = new QLabel(this);
    label_3->setObjectName(QString::fromUtf8("label_3"));
    label_3->setGeometry(QRect(330, 190, 101, 17));

    label_2->setText(QCoreApplication::translate("MainWindow", "CARSPEED", nullptr));
    label->setText(QCoreApplication::translate("MainWindow", "Engine RPM", nullptr));
    label_3->setText(QCoreApplication::translate("MainWindow", "Break Gauge", nullptr));


    labelled1 = new QLabel(this);
    labelled1->setObjectName(QString::fromUtf8("labelled1"));
    labelled1->setGeometry(QRect(5, 260, 30, 10));
    labelled1->setText(QCoreApplication::translate("MainWindow", "LKAS", nullptr));
    labelled1->setStyleSheet("font-size: 10px;");

    labelled2 = new QLabel(this);
    labelled2->setObjectName(QString::fromUtf8("labelled2"));
    labelled2->setGeometry(QRect(45, 260, 30, 10));
    labelled2->setText(QCoreApplication::translate("MainWindow", "SPEED", nullptr));
    labelled2->setStyleSheet("font-size: 10px;");

    labelled3 = new QLabel(this);
    labelled3->setObjectName(QString::fromUtf8("labelled3"));
    labelled3->setGeometry(QRect(85, 260, 30, 10));
    labelled3->setText(QCoreApplication::translate("MainWindow", "WARN", nullptr));
    labelled3->setStyleSheet("font-size: 10px;");

    labelled4 = new QLabel(this);
    labelled4->setObjectName(QString::fromUtf8("labelled4"));
    labelled4->setGeometry(QRect(125, 260, 30, 10));
    labelled4->setText(QCoreApplication::translate("MainWindow", "START", nullptr));
    labelled4->setStyleSheet("font-size: 10px;");

    progressBar = new QProgressBar(this);
    progressBar->setObjectName(QString::fromUtf8("progressBar"));
    progressBar->setGeometry(QRect(320, 220, 118, 23));
    progressBar->setMaximum(100);
    progressBar->setValue(0);
    rpmValue = -123;
    carSpeed = 50;
#if 0
    AutowayQpix = QImage(":/resources/Lkas.jpg");
    if (AutowayQpix.isNull()) {
        qDebug() << "AutowayQpix imageload failed";
    }
    startQpix.load(":/resources/on.jpg");
    if (startQpix.isNull()) {
        qDebug() << "startQpix imageload failed";
    }
    StopQpix.load(":/resources/off.jpg");
    if (StopQpix.isNull()) {
        qDebug() << "StopQpix imageload failed";
    }
    warningQpix.load(":/resources/warning.jpg");
    if (warningQpix.isNull()) {
        qDebug() << "warningQpix imageload failed";
    }
    SpeedRestrictQpix.load(":/resources/banner.jpg");
    if (SpeedRestrictQpix.isNull()) {
        qDebug() << "SpeedRestrictQpix imageload failed";
    }
#endif
    //ui->lcdNumber->move(160,180);
    //ui->lcdNumber_2->move(160,480);
    svgRenderer = new QSvgRenderer(QStringLiteral(":/resources/gauge2.svg"), this);
    NeedlesvgRenderer = new QSvgRenderer(QStringLiteral(":/resources/needle.svg"), this);
    openCanSocket();
 /*
    QObject::connect(device, &QCanBusDevice::framesReceived, [&]() {
            while (device->framesAvailable()) {
                QCanBusFrame rxFrame = device->readFrame();
                qDebug() << "수신된 프레임:";
                qDebug() << " ID:" << QString::number(rxFrame.frameId(), 16);
                qDebug() << " Data:" << rxFrame.payload().toHex();
            }
        });*/
    connect(device, &QCanBusDevice::framesReceived, this, &MainWindow::onCanFrameReceived);
    connect(device, &QCanBusDevice::errorOccurred, this, &MainWindow::processCanError);
}

MainWindow::~MainWindow()
{
    //delete ui;
}

void MainWindow::paintEvent(QPaintEvent *) {

    //painter.setRenderHint(QPainter::Antialiasing);
    QPainter painter(this);
    //int centerX = width() / 2;
    //int centerY = height() / 2;
    //int radius = qMin(width(), height()) / 2 - 10;

    //painter.translate(centerX, centerY);

    // 배경 원
    //painter.setPen(Qt::NoPen);
    //painter.setBrush(Qt::gray);
    //painter.drawEllipse(QPoint(0, 0), radius, radius);
#if 0
    QImage tmpQpix(":/resources/Lkas.jpg");
    if (tmpQpix.isNull()) {
        qDebug() << "tmpQpix imageload failed";
    }
    QRect target(240, 240, 25, 25);
    painter.drawImage(target, tmpQpix);

    QImage tmpQpix2(":/resources/Lkas.jpg");
    if (tmpQpix2.isNull()) {
        qDebug() << "tmpQpix imageload failed";
    }
    QRect target2(260, 240, 25, 25);
    painter.drawImage(target2, tmpQpix2);
#endif
    // 바늘
    //painter.setPen(QPen(Qt::red, 3));
    //double angle = 180 * value / 100.0; // 0~180도
    //painter.rotate(angle);
    //painter.drawLine(0, 0, 0, -radius + 20);
    //QPointF center = QPointF(width() / 2.0, height() / 2.0);
    CarSpeed(carSpeed,painter); //-123 50 173 -123
    Rpm(rpmValue,painter);
    warningDraw(painter);
    StartStopDraw(painter);
    AutowayDraw(painter);
    SpeedDraw(painter);
    //NeedlesvgRenderer->render(&painter,rect());
    //renderer->render(&painter, QString("needle"), QRectF(x, y, w, h));
}

QPointF MainWindow::transpointCal(void)
{
    QSizeF viewBoxSize(500, 190);         // SVG 뷰박스 크기
    QSizeF pixelSize = NeedlesvgRenderer->defaultSize();

    QPointF viewBoxCenter(50, 100);       // 뷰박스 내 회전 중심 좌표

    // 픽셀 좌표 변환
    qreal px = viewBoxCenter.x() * (pixelSize.width() / viewBoxSize.width());
    qreal py = viewBoxCenter.y() * (pixelSize.height() / viewBoxSize.height());

    QPointF rotationCenter(px, py);
    return rotationCenter;
}
QRectF MainWindow::calculateAspectRatioFit(QSizeF srcSize, QRectF dstRect)
{
    qreal srcAspect = srcSize.width() / srcSize.height();
    qreal dstAspect = dstRect.width() / dstRect.height();

    QRectF result = dstRect;

    if (srcAspect > dstAspect) {
        // Fit to width
        qreal scaledHeight = dstRect.width() / srcAspect;
        result.setTop(dstRect.top() + (dstRect.height() - scaledHeight) / 2);
        result.setHeight(scaledHeight);
    } else {
        // Fit to height
        qreal scaledWidth = dstRect.height() * srcAspect;
        result.setLeft(dstRect.left() + (dstRect.width() - scaledWidth) / 2);
        result.setWidth(scaledWidth);
    }

    return result;
}
void MainWindow::Rpm(int value,QPainter &painter)
{
     painter.save();
     //QPainter painter(this);
    QRectF myTargetArea(50, 20, 200, 200); // x=100, y=100, width=200, height=200
    QRectF targetRect = calculateAspectRatioFit(
        QSizeF(NeedlesvgRenderer->defaultSize()),  // SVG 원본 사이즈
        myTargetArea//rect()                                  // 실제 그릴 영역
    );
    QRectF targetRect2 = calculateAspectRatioFit(
        QSizeF(svgRenderer->defaultSize()),  // SVG 원본 사이즈
        myTargetArea//rect()                                  // 실제 그릴 영역
    );
    svgRenderer->render(&painter,targetRect2);
    QPointF center = targetRect.center();

        painter.setRenderHint(QPainter::Antialiasing, true);
        //QPointF rotationCenter=transpointCal();
        //center.setX(center.x()-70);
        //center.setY(center.y()-70);
        //painter.translate(center);      // 1. 중심으로 이동
        //painter.rotate(-50);    // 2. 각도만큼 회전 (시계방향)
        //center.rx();
        //center.ry();
        //center.setX(center.x());
        center.setY(center.y()+10);
        painter.translate(center);     // 3. 원래 위치로 복원 (중심 기준 회전 완료)
        painter.rotate(value);
        painter.translate(-center);
        // SVG 렌더링
        if (NeedlesvgRenderer && NeedlesvgRenderer->isValid()) {
            NeedlesvgRenderer->render(&painter, targetRect); // 사각형 기준으로 그림
        }
         painter.restore();
}

void MainWindow::CarSpeed(int value ,QPainter &painter)
{
     //QPainter painter(this);
    painter.save();
    QRectF myTargetArea(250, 20, 200, 200); // x=100, y=100, width=200, height=200
    QRectF targetRect = calculateAspectRatioFit(
        QSizeF(NeedlesvgRenderer->defaultSize()),  // SVG 원본 사이즈
        myTargetArea//rect()                                  // 실제 그릴 영역
    );
    QRectF targetRect2 = calculateAspectRatioFit(
        QSizeF(svgRenderer->defaultSize()),  // SVG 원본 사이즈
        myTargetArea//rect()                                  // 실제 그릴 영역
    );
    svgRenderer->render(&painter,targetRect2);
    QPointF center = targetRect.center();

        painter.setRenderHint(QPainter::Antialiasing, true);
        //QPointF rotationCenter=transpointCal();
        //center.setX(center.x()-70);
        //center.setY(center.y()-70);
        //painter.translate(center);      // 1. 중심으로 이동
        //painter.rotate(-50);    // 2. 각도만큼 회전 (시계방향)
        //center.rx();
        //center.ry();
        //center.setX(center.x());
        center.setY(center.y()+10);
        painter.translate(center);     // 3. 원래 위치로 복원 (중심 기준 회전 완료)
        painter.rotate(value);
        painter.translate(-center);
        // SVG 렌더링
        if (NeedlesvgRenderer && NeedlesvgRenderer->isValid()) {
            NeedlesvgRenderer->render(&painter, targetRect); // 사각형 기준으로 그림
        }
        painter.restore();
}

void MainWindow::openCanSocket(void) {
    //QCanBusDevice::Filter blockAllFilter;

    device = QCanBus::instance()->createDevice("socketcan", "can0");
    //blockAllFilter.frameId = 0x000;
    //blockAllFilter.frameIdMask = 0x000;  // 마스크가 0이면 모든 메시지를 차단

    //device->setConfigurationParameter(QCanBusDevice::RawFilterKey,
    //                                     QVariant::fromValue(QList<QCanBusDevice::Filter> { blockAllFilter }));
       if (!device) {
           qDebug() << "CAN device create failed";
           //return -1;
       }

       if (!device->connectDevice()) {
           qDebug() << "CAN connect failed:" << device->errorString();
           //return -1;
       }
       //device->resetController();
     //device->setConfigurationParameter(QCanBusDevice::RawFilterKey,
     //                                       QVariant::fromValue(QList<QCanBusDevice::Filter>()));
       qDebug() << "CAN connection success";
}
#if 0
void MainWindow::onMyButtonClicked()
{
    qDebug() << "StartStop clicked!";
    btnmsg ^= 1;
    //ui->checkBox_2->setChecked(true);
    QCanBusFrame txFrame(0x401,QByteArray(1, btnmsg) );
    if (!device->writeFrame(txFrame)) {
        qDebug() << "send failed:" << device->errorString();
    }
}

void MainWindow::onMyButtonClicked2()
{
    btnmsg ^= 1<<1;
    //ui->checkBox->setChecked(true);
    qDebug() << "AutoWay clicked";
    QCanBusFrame txFrame(0x401,QByteArray(1, btnmsg) );//QByteArray::fromHex("1122334455667788"));
    if (!device->writeFrame(txFrame)) {
        qDebug() << "send failed:" << device->errorString();
    }
}
#endif
void MainWindow::onCanFrameReceived()
{
    while (device->framesAvailable()) {
        QCanBusFrame rxFrame = device->readFrame();
        //qDebug() << "Rx frame:";
        //qDebug() << " ID:" << QString::number(rxFrame.frameId(), 16);
        //qDebug() << " Data:" << rxFrame.payload().toHex();
        if(rxFrame.frameId() == 0x403)
        {
            QByteArray data = rxFrame.payload();
            int temp = (int)static_cast<quint8>(data[2]);
             carSpeed = temp*173/220 - 123;
             temp = static_cast<quint8>(data[1]) << 8 | static_cast<quint8>(data[0]);
             rpmValue = temp*173/125 -123;
             //qDebug() << " RPM:" << temp<<"RPMvalue:"<<rpmValue;
        }else if(rxFrame.frameId() == 0x321)
        {
            QByteArray data2 = rxFrame.payload();
            uint16_t value2 = (uint16_t)(static_cast<quint8>(data2[1]) << 8 | static_cast<quint8>(data2[0]));
            //qDebug() << " Break:" << value2;
             //carSpeed = (int)static_cast<quint8>(data[2]);
            if(value2 == 0 )
            {
             progressBar->setValue(0);
             //qDebug() << " value 0";
            }else if(value2 == 1)
            {
             progressBar->setValue(50);
             //qDebug() << " value 50";
            }else if(value2 ==2)
            {
             progressBar->setValue(100);
             //qDebug() << " value 100";
            }

        }else if(rxFrame.frameId() == 0x341)//adas state
        {
            QByteArray data341 = rxFrame.payload();
            uint8_t value341 = (uint8_t)(static_cast<quint8>(data341[0]));
            AdasState = value341;
        }else if(rxFrame.frameId() == 0x343)//release break
        {
            if(AdasState == 1)
            {
               //warning = 1; release break
            }

        }else if(rxFrame.frameId() == 0x301)
        {
            QByteArray data301 = rxFrame.payload();
            uint8_t value301 = (uint8_t)(static_cast<quint8>(data301[0]));
            //value302
            if(value301 != 0)
            {
                warning = 0;
            }else{
                warning = 1;
            }
        }else if(rxFrame.frameId() == 0x302)
        {
            QByteArray data302 = rxFrame.payload();
            uint8_t value302 = (uint8_t)(static_cast<quint8>(data302[0]));
            //value302
            if(value302 == 1)
            {
                SpeedRestrict = 1;
            }else{
                SpeedRestrict = 0;
            }
        }else if(rxFrame.frameId() == 0x401)
        {
            QByteArray data401 = rxFrame.payload();
            uint8_t value401 = (uint8_t)(static_cast<quint8>(data401[0]));
            Autoway = value401>>1;
            startStop = value401&1;
        }

    }//2ea 이상 들어오는 경우 사용
    update();
}

void MainWindow::warningDraw(QPainter &painter)
{
    painter.save();
    //QPainter painter(this);
    //QPoint imagePos;
    //QSize imageSize;
    //imagePos = QPoint(90, 240);
    //imageSize = QSize(25, 25);
    //QPixmap scaledPixmap = warningQpix.scaled(imageSize, Qt::KeepAspectRatio, Qt::SmoothTransformation);
       if (warning ==1)//&& !warningQpix.isNull())
       {
           //QRect target(90, 240, 25, 25);
           //painter.drawImage(target, warningQpix);
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::red);
           painter.drawEllipse(QPoint(100, 240), radius, radius);
           //painter.drawPixmap(imagePos, scaledPixmap);//painter.drawPixmap(50, 50, AutowayQpix);
       }else{
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::white);
           painter.drawEllipse(QPoint(100, 240), radius, radius);
       }
       painter.restore();
}
void MainWindow::StartStopDraw(QPainter &painter)
{
    painter.save();
    //QPainter painter(this);


       if (startStop ==1)//&& !startQpix.isNull())
       {
           //QRect target(130, 245, 25, 25);
           //painter.drawImage(target, startQpix);
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::blue);
           painter.drawEllipse(QPoint(140, 240), radius, radius);

       }else if(startStop==0 )//&& !StopQpix.isNull())
       {
           //QRect target(130, 245, 25, 25);
           //painter.drawImage(target, StopQpix);
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::white);
           painter.drawEllipse(QPoint(140, 240), radius, radius);
       }
       painter.restore();
}
void MainWindow::AutowayDraw(QPainter &painter)
{
    painter.save();
    //QPainter painter(this);

       if (Autoway == 1)//&& !AutowayQpix.isNull())
       {
           //QRect target(10, 245, 30, 30);
           //painter.drawImage(target, AutowayQpix);
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::green);
           painter.drawEllipse(QPoint(20, 240), radius, radius);
           //painter.drawPixmap(imagePos, scaledPixmap);//painter.drawPixmap(50, 50, AutowayQpix);
       }else{
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::white);
           painter.drawEllipse(QPoint(20, 240), radius, radius);
       }
       painter.restore();
}
void MainWindow::SpeedDraw(QPainter &painter)
{
    painter.save();
    //QPainter painter(this);
       if (SpeedRestrict == 1) //&& !SpeedRestrictQpix.isNull())
       {
           //QRect target(50, 240, 30, 30);
           //painter.drawImage(target, SpeedRestrictQpix);
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::magenta);
           painter.drawEllipse(QPoint(60, 240), radius, radius);
       }else
       {
           int radius = 15;
           painter.setPen(Qt::NoPen);
           painter.setBrush(Qt::white);
           painter.drawEllipse(QPoint(60, 240), radius, radius);
       }
       painter.restore();
}

void MainWindow::processCanError(QCanBusDevice::CanBusError error)
{
    QString errStr = device->errorString();
    qWarning() << "CAN Error code:" << error << ", msg:" << errStr;
    device->disconnectDevice();
    device->resetController();
    QThread::sleep(1); // or QTimer::singleShot for 비차단
      if (!device->connectDevice()) {
          qCritical() << "CAN reconnect failed" << device->errorString();
      } else {
          qInfo() << "CAN reconnect success";
      }
}
//uint8_t Autoway = 0;
//uint8_t startStop = 0;
//uint8_t warning = 0;
//uint8_t SpeedRestrict = 0;
//uint8_t AdasState
